class ToDoList:
    def __init__(self):
        self.tasks = {}

    def add_task(self, task_name, due_date=None):
        
        task_id = len(self.tasks) + 1
        self.tasks[task_id] = {"task_name": task_name, "due_date": due_date, "status": "Not Started"}
        print(f"Task '{task_name}' added successfully!")

    def view_tasks(self):
       
        if not self.tasks:
            print("No tasks available!")
        else:
            for task_id, task in self.tasks.items():
                print(f"Task ID: {task_id}")
                print(f"Task Name: {task['task_name']}")
                print(f"Due Date: {task['due_date']}")
                print(f"Status: {task['status']}\n")

    def update_task(self, task_id, task_name=None, due_date=None, status=None):
      
        if task_id in self.tasks:
            if task_name:
                self.tasks[task_id]["task_name"] = task_name
            if due_date:
                self.tasks[task_id]["due_date"] = due_date
            if status:
                self.tasks[task_id]["status"] = status
            print(f"Task {task_id} updated successfully!")
        else:
            print(f"Task {task_id} not found!")

    def delete_task(self, task_id):
      
        if task_id in self.tasks:
            del self.tasks[task_id]
            print(f"Task {task_id} deleted successfully!")
        else:
            print(f"Task {task_id} not found!")


def main():
    todo = ToDoList()

    while True:
        print("\nTo-Do List Menu:")
        print("1. Add Task")
        print("2. View Tasks")
        print("3. Update Task")
        print("4. Delete Task")
        print("5. Quit")

        choice = input("Enter your choice: ")

        if choice == "1":
            task_name = input("Enter task name: ")
            due_date = input("Enter due date (optional): ")
            todo.add_task(task_name, due_date)
        elif choice == "2":
            todo.view_tasks()
        elif choice == "3":
            task_id = int(input("Enter task ID: "))
            task_name = input("Enter new task name (optional): ")
            due_date = input("Enter new due date (optional): ")
            status = input("Enter new status (optional): ")
            todo.update_task(task_id, task_name, due_date, status)
        elif choice == "4":
            task_id = int(input("Enter task ID: "))
            todo.delete_task(task_id)
        elif choice == "5":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()